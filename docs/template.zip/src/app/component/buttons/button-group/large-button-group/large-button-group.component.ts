import { Component } from '@angular/core';
import { commongroupButton } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-large-button-group',
  templateUrl: './large-button-group.component.html',
  styleUrls: ['./large-button-group.component.scss']
})
export class LargeButtonGroupComponent {

  public largbuttongroup = commongroupButton;

}
