import { Component } from '@angular/core';
import { CommonOutline } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-outline-flat-button',
  templateUrl: './outline-flat-button.component.html',
  styleUrls: ['./outline-flat-button.component.scss']
})
export class OutlineFlatButtonComponent {

  public outlinedata = CommonOutline;

}
