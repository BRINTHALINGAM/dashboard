import { Component } from '@angular/core';
import { CommonOutline } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-outline-button-group',
  templateUrl: './outline-button-group.component.html',
  styleUrls: ['./outline-button-group.component.scss']
})
export class OutlineButtonGroupComponent {

  public outlinedata = CommonOutline;

}
