import { Component } from '@angular/core';
import { commongroupButton } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-basic-button',
  templateUrl: './basic-button.component.html',
  styleUrls: ['./basic-button.component.scss']
})
export class BasicButtonComponent {

  public basicgropuData = commongroupButton;

}
