import { Component } from '@angular/core';

@Component({
  selector: 'app-nesting',
  templateUrl: './nesting.component.html',
  styleUrls: ['./nesting.component.scss']
})
export class NestingComponent {

}
