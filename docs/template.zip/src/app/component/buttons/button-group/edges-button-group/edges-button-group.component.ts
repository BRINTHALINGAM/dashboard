import { Component } from '@angular/core';
import { commongroupButton } from '../../../../shared/data/component/buttons/button-group';
@Component({
  selector: 'app-edges-button-group',
  templateUrl: './edges-button-group.component.html',
  styleUrls: ['./edges-button-group.component.scss']
})
export class EdgesButtonGroupComponent {

  public edgegroupData = commongroupButton;

}
