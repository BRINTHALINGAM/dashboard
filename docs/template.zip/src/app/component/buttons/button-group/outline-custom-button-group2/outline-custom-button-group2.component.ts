import { Component } from '@angular/core';
import { outlinecustomData } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-outline-custom-button-group2',
  templateUrl: './outline-custom-button-group2.component.html',
  styleUrls: ['./outline-custom-button-group2.component.scss']
})
export class OutlineCustomButtonGroup2Component {

  public outlinecustom = outlinecustomData;

}
