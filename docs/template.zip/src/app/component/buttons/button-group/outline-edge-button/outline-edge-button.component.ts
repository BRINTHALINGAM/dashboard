import { Component } from '@angular/core';
import { CommonOutline } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-outline-edge-button',
  templateUrl: './outline-edge-button.component.html',
  styleUrls: ['./outline-edge-button.component.scss']
})
export class OutlineEdgeButtonComponent {

  public outlinedata = CommonOutline;

}
