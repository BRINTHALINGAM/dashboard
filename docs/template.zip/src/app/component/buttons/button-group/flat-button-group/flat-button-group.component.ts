import { Component } from '@angular/core';
import { commongroupButton } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-flat-button-group',
  templateUrl: './flat-button-group.component.html',
  styleUrls: ['./flat-button-group.component.scss']
})
export class FlatButtonGroupComponent {

  public FlatgroupData = commongroupButton;

}
