import { Component } from '@angular/core';
import { checkboxData } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-check-box-button-group',
  templateUrl: './check-box-button-group.component.html',
  styleUrls: ['./check-box-button-group.component.scss']
})
export class CheckBoxButtonGroupComponent {

  public checkBox = checkboxData;

}
