import { Component } from '@angular/core';
import { commongroupButton } from '../../../../shared/data/component/buttons/button-group';

@Component({
  selector: 'app-large-edges-group',
  templateUrl: './large-edges-group.component.html',
  styleUrls: ['./large-edges-group.component.scss']
})
export class LargeEdgesGroupComponent {

  public largedgebuttongroup = commongroupButton;

}
