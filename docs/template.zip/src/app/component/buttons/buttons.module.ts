import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { ButtonsRoutingModule } from './buttons-routing.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

import { DefaultStyleComponent } from './default-style/default-style.component';
import { EdgeStyleComponent } from './edge-style/edge-style.component';
import { RaisedStyleComponent } from './raised-style/raised-style.component';
import { FlatStyleComponent } from './flat-style/flat-style.component';
import { ButtonGroupComponent } from './button-group/button-group.component';
import { BasicButtonComponent } from './button-group/basic-button/basic-button.component';
import { EdgesButtonGroupComponent } from './button-group/edges-button-group/edges-button-group.component';
import { FlatButtonGroupComponent } from './button-group/flat-button-group/flat-button-group.component';
import { LargeButtonGroupComponent } from './button-group/large-button-group/large-button-group.component';
import { LargeEdgesGroupComponent } from './button-group/large-edges-group/large-edges-group.component';
import { OutlineCustomButtonGroupComponent } from './button-group/outline-custom-button-group/outline-custom-button-group.component';
import { OutlineCustomButtonGroup2Component } from './button-group/outline-custom-button-group2/outline-custom-button-group2.component';
import { OutlineButtonGroupComponent } from './button-group/outline-button-group/outline-button-group.component';
import { OutlineEdgeButtonComponent } from './button-group/outline-edge-button/outline-edge-button.component';
import { OutlineFlatButtonComponent } from './button-group/outline-flat-button/outline-flat-button.component';
import { RadioButtonGroupComponent } from './button-group/radio-button-group/radio-button-group.component';
import { CheckBoxButtonGroupComponent } from './button-group/check-box-button-group/check-box-button-group.component';
import { NestingComponent } from './button-group/nesting/nesting.component';
import { VerticalComponent } from './button-group/vertical/vertical.component';


@NgModule({
  declarations: [
    DefaultStyleComponent,
    EdgeStyleComponent,
    RaisedStyleComponent,
    FlatStyleComponent,
    ButtonGroupComponent,
    BasicButtonComponent,
    EdgesButtonGroupComponent,
    FlatButtonGroupComponent,
    LargeButtonGroupComponent,
    LargeEdgesGroupComponent,
    OutlineCustomButtonGroupComponent,
    OutlineCustomButtonGroup2Component,
    OutlineButtonGroupComponent,
    OutlineEdgeButtonComponent,
    OutlineFlatButtonComponent,
    RadioButtonGroupComponent,
    CheckBoxButtonGroupComponent,
    NestingComponent,
    VerticalComponent,
  ],
  imports: [
    CommonModule,
    ButtonsRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgbTooltipModule,
    NgbDropdownModule
  ]
})
export class ButtonsModule { }
