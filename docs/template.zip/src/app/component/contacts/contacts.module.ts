import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactsRoutingModule } from './contacts-routing.module';
import { ContactsComponent } from './contacts.component';
import { ContactSidemenuComponent } from './contact-sidemenu/contact-sidemenu.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPrintModule } from 'ngx-print';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';

import { PersonalComponent } from './personal/personal.component';
import { AddCategoryComponent } from './modal/add-category/add-category.component';
import { NewContactComponent } from './modal/new-contact/new-contact.component';
import { ProfileDataComponent } from './personal/profile-data/profile-data.component';
import { GeneralComponent } from './personal/profile-data/edit-profile/general/general.component';
import { PersonalContentComponent } from './personal/profile-data/edit-profile/personal-content/personal-content.component';
import { PrintComponent } from './modal/print/print.component';
import { AddressContentComponent } from './personal/profile-data/edit-profile/address-content/address-content.component';

@NgModule({
  declarations: [
    ContactsComponent,
    ContactSidemenuComponent,
    PersonalComponent,
    AddCategoryComponent,
    NewContactComponent,
    ProfileDataComponent,
    GeneralComponent,
    PersonalContentComponent,
    PrintComponent,
    AddressContentComponent
  ],
  imports: [
    CommonModule,
    ContactsRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPrintModule,
  ],
  providers: [
    NgbActiveModal
  ]
})
export class ContactsModule { }
