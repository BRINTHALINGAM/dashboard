import { Component, Input, Output, SimpleChanges } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as data from '../../../shared/data/component/contacts/all-contact';
import { AddCategoryComponent } from '../modal/add-category/add-category.component';
import { NewContactComponent } from '../modal/new-contact/new-contact.component';

@Component({
  selector: 'app-contact-sidemenu',
  templateUrl: './contact-sidemenu.component.html',
  styleUrls: ['./contact-sidemenu.component.scss']
})
export class ContactSidemenuComponent {

  @Output() selectedId: number;
  @Output() statusData: boolean;
  @Output() getTitleData: string;
  @Output() titleData: string;

  public Personal = data.Personal;
  public organization = data.Organization;
  public viewList = data.viewList;
  public open: boolean = false;
  public lastData: data.lastDataList;
  
  constructor(private modalService: NgbModal) { }

  ngOnInit(changes: SimpleChanges) {
    let getStatusdata = this.Personal.filter((data) => {
      return data.status == true;
    })
    this.statusData = getStatusdata[0]?.status;
  }

  newContacts() {
    const model = this.modalService.open(NewContactComponent, { size: 'lg' });
  }

  addCategory() {
    const model = this.modalService.open(AddCategoryComponent, { size: 'SM' });
  }

  changeData(list: number, title: string) {
    const getId = this.Personal.filter(x => x.title_id == list);
    this.selectedId = getId[0].title_id;
    const getTitleData = this.Personal.filter(x => x.title = title);
    this.titleData = getTitleData[0].title;
  }

  changeData1(list: number) {
    const getId = this.organization.filter(x => x.title_id == list);
    this.selectedId = getId[0].title_id;
  }

  openMenu() {
    this.open = !this.open;
  }
}
