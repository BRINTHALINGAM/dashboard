import { Component } from '@angular/core';
import * as saleschart from '../../../../shared/data/component/deshboard/crm-dashboard-charts';

@Component({
  selector: 'app-sales-analyics',
  templateUrl: './sales-analyics.component.html',
  styleUrls: ['./sales-analyics.component.scss']
})
export class SalesAnalyicsComponent {

  public SalesAnalyicData = saleschart.SalesAnalyics;

}
