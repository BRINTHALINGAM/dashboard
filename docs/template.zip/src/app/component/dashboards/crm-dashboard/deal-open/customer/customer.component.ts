import { Component } from '@angular/core';
import { customer } from '../../../../../shared/data/component/deshboard/crm-dashboard';
import * as customerChats from '../../../../../shared/data/component/deshboard/crm-dashboard-charts';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent {

  public CustomerData = customer;
  public CustomerChatData = customerChats.customerChat;

}
