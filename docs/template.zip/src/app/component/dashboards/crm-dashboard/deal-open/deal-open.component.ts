import { Component } from '@angular/core';
import { dealOpen } from '../../../../shared/data/component/deshboard/crm-dashboard';

@Component({
  selector: 'app-deal-open',
  templateUrl: './deal-open.component.html',
  styleUrls: ['./deal-open.component.scss']
})
export class DealOpenComponent {

  public dealopenData = dealOpen;

}
