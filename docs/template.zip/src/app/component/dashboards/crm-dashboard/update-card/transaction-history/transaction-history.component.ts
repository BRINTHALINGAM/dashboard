import { Component } from '@angular/core';
import { TransactionData } from '../../../../../shared/data/component/deshboard/crm-dashboard';

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.scss']
})
export class TransactionHistoryComponent {

  public transactionHistory = TransactionData;

}
