import { Component } from '@angular/core';
import { TopCustomer } from '../../../../shared/data/component/deshboard/crm-dashboard';

@Component({
  selector: 'app-top-customer',
  templateUrl: './top-customer.component.html',
  styleUrls: ['./top-customer.component.scss']
})
export class TopCustomerComponent {

  public topcustomerdata = TopCustomer;

}
