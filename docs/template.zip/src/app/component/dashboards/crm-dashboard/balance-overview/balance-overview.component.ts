import { Component } from '@angular/core';
import * as balncechart from '../../../../shared/data/component/deshboard/crm-dashboard-charts';

@Component({
  selector: 'app-balance-overview',
  templateUrl: './balance-overview.component.html',
  styleUrls: ['./balance-overview.component.scss']
})
export class BalanceOverviewComponent {

  public balnceOverviewData = balncechart.balnceOverview;

}
