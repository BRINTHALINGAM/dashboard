import { Component } from '@angular/core';

@Component({
  selector: 'app-shopping-place',
  templateUrl: './shopping-place.component.html',
  styleUrls: ['./shopping-place.component.scss']
})
export class ShoppingPlaceComponent {

}
