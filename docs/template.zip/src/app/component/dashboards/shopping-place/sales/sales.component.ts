import { Component } from '@angular/core';
import { sales } from '../../../../shared/data/component/deshboard/shopping-place';
import * as saleschart from '../../../../shared/data/component/deshboard/charts';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.scss']
})
export class SalesComponent {

  public salesData = sales;
  public saleschartData = saleschart.saleschart;

}
