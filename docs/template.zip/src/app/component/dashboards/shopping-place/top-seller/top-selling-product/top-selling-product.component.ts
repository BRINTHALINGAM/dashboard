import { Component } from '@angular/core';

@Component({
  selector: 'app-top-selling-product',
  templateUrl: './top-selling-product.component.html',
  styleUrls: ['./top-selling-product.component.scss']
})
export class TopSellingProductComponent {

}
