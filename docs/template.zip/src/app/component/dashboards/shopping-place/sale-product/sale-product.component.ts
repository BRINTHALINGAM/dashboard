import { Component } from '@angular/core';
import * as saleschart from '../../../../shared/data/component/deshboard/charts';

@Component({
  selector: 'app-sale-product',
  templateUrl: './sale-product.component.html',
  styleUrls: ['./sale-product.component.scss']
})
export class SaleProductComponent {

  public salesChartData = saleschart.saleproductchart;

}
