import { Component } from '@angular/core';
import { newProduct } from '../../../../shared/data/component/deshboard/shopping-place';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.scss']
})
export class NewProductComponent {

  public productData = newProduct;

}
