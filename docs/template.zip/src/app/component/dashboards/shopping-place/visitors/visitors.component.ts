import { Component } from '@angular/core';
import { vistors } from '../../../../shared/data/component/deshboard/shopping-place';
import * as incomcharts from '../../../../shared/data/component/deshboard/charts';

@Component({
  selector: 'app-visitors',
  templateUrl: './visitors.component.html',
  styleUrls: ['./visitors.component.scss']
})
export class VisitorsComponent {

  public visitorData = vistors;
  public incomechartData = incomcharts.incomechart;

}
