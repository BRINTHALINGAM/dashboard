import { Component } from '@angular/core';
import { saleProductoffer } from '../../../../shared/data/component/deshboard/shopping-place';

@Component({
  selector: 'app-sale-offer',
  templateUrl: './sale-offer.component.html',
  styleUrls: ['./sale-offer.component.scss']
})
export class SaleOfferComponent {

  public salesofferData = saleProductoffer;

}
