import { Component } from '@angular/core';
import { activityTimeline } from '../../../../shared/data/component/deshboard/shopping-place';

@Component({
  selector: 'app-activity-timeline',
  templateUrl: './activity-timeline.component.html',
  styleUrls: ['./activity-timeline.component.scss']
})
export class ActivityTimelineComponent {

  public timelineitem = activityTimeline;

}
