import { Component } from '@angular/core';
import { Earning } from '../../../../shared/data/component/deshboard/shopping-place';
import * as eraning from '../../../../shared/data/component/deshboard/charts';

@Component({
  selector: 'app-earning',
  templateUrl: './earning.component.html',
  styleUrls: ['./earning.component.scss']
})
export class EarningComponent {

  public erningdata = Earning;
  public erningchart = eraning.EarningData;

}
