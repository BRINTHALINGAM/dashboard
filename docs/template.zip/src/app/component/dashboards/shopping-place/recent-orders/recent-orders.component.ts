import { Component } from '@angular/core';
import { recentOrder } from '../../../../shared/data/component/deshboard/shopping-place';

@Component({
  selector: 'app-recent-orders',
  templateUrl: './recent-orders.component.html',
  styleUrls: ['./recent-orders.component.scss']
})
export class RecentOrdersComponent {

  public orderitem = recentOrder;

}
