import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShoppingPlaceComponent } from './shopping-place/shopping-place.component';
import { CrmDashboardComponent } from './crm-dashboard/crm-dashboard.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'default',
        component: ShoppingPlaceComponent,
        data: {
          title: "Shopping Place Dashboard",
          breadcrumb: "Default",
        }
      },
      {
        path: 'crm-dashboard',
        component: CrmDashboardComponent,
        data: {
          title: "CRM-Dashboard",
          breadcrumb: "CRM-Dashboard",
        }
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardsRoutingModule { }
