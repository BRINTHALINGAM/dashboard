import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { DashboardsRoutingModule } from './dashboards-routing.module';
import { NgApexchartsModule } from 'ng-apexcharts';
import { LeafletModule } from '@asymmetrik/ngx-leaflet';
import { ShoppingPlaceComponent } from './shopping-place/shopping-place.component';
import { EarningComponent } from './shopping-place/earning/earning.component';
import { SalesComponent } from './shopping-place/sales/sales.component';
import { VisitorsComponent } from './shopping-place/visitors/visitors.component';
import { RecentOrdersComponent } from './shopping-place/recent-orders/recent-orders.component';
import { TopSellerComponent } from './shopping-place/top-seller/top-seller.component';
import { TopSellingProductComponent } from './shopping-place/top-seller/top-selling-product/top-selling-product.component';
import { NewProductComponent } from './shopping-place/new-product/new-product.component';
import { TopCountriesComponent } from './shopping-place/top-countries/top-countries.component';
import { ActivityTimelineComponent } from './shopping-place/activity-timeline/activity-timeline.component';
import { SalesSummaryComponent } from './shopping-place/sales-summary/sales-summary.component';
import { SaleProductComponent } from './shopping-place/sale-product/sale-product.component';
import { InvoiceComponent } from './shopping-place/invoice/invoice.component';
import { SaleOfferComponent } from './shopping-place/sale-offer/sale-offer.component';
import { CrmDashboardComponent } from './crm-dashboard/crm-dashboard.component';
import { UpdateCardComponent } from './crm-dashboard/update-card/update-card.component';
import { TransactionHistoryComponent } from './crm-dashboard/update-card/transaction-history/transaction-history.component';
import { TopCustomerComponent } from './crm-dashboard/top-customer/top-customer.component';
import { AllNotificationComponent } from './crm-dashboard/all-notification/all-notification.component';
import { BalanceOverviewComponent } from './crm-dashboard/balance-overview/balance-overview.component';
import { SalesAnalyicsComponent } from './crm-dashboard/sales-analyics/sales-analyics.component';
import { DealOpenComponent } from './crm-dashboard/deal-open/deal-open.component';
import { CommonAnalyicsComponent } from './crm-dashboard/sales-analyics/common-analyics/common-analyics.component';
import { CustomerComponent } from './crm-dashboard/deal-open/customer/customer.component';


@NgModule({
  declarations: [
    ShoppingPlaceComponent,
    EarningComponent,
    SalesComponent,
    VisitorsComponent,
    RecentOrdersComponent,
    TopSellerComponent,
    TopSellingProductComponent,
    NewProductComponent,
    TopCountriesComponent,
    ActivityTimelineComponent,
    SalesSummaryComponent,
    SaleProductComponent,
    InvoiceComponent,
    SaleOfferComponent,
    CrmDashboardComponent,
    UpdateCardComponent,
    TransactionHistoryComponent,
    TopCustomerComponent,
    AllNotificationComponent,
    BalanceOverviewComponent,
    SalesAnalyicsComponent,
    DealOpenComponent,
    CommonAnalyicsComponent,
    CustomerComponent,
  ],
  imports: [
    CommonModule,
    DashboardsRoutingModule,
    SharedModule,
    NgApexchartsModule,
    LeafletModule,
    ReactiveFormsModule,
    FormsModule,
  ]
})
export class DashboardsModule { }
