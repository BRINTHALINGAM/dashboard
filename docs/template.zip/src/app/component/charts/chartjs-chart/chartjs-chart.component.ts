import { Component } from '@angular/core';

@Component({
  selector: 'app-chartjs-chart',
  templateUrl: './chartjs-chart.component.html',
  styleUrls: ['./chartjs-chart.component.scss']
})
export class ChartjsChartComponent {

}
