import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/charts';

@Component({
  selector: 'app-basic-area-chart',
  templateUrl: './basic-area-chart.component.html',
  styleUrls: ['./basic-area-chart.component.scss']
})
export class BasicAreaChartComponent {

  public turnover = chartData.splineArea1

}
