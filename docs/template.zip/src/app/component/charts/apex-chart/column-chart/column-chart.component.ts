import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/charts';

@Component({
  selector: 'app-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.scss']
})
export class ColumnChartComponent {

  public columnChart = chartData.columnChart

}
