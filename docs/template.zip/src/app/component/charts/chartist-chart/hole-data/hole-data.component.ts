import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-hole-data',
  templateUrl: './hole-data.component.html',
  styleUrls: ['./hole-data.component.scss']
})
export class HoleDataComponent {

  public chart11 = chartData.chart11;

}
