import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-advanced-smil',
  templateUrl: './advanced-smil.component.html',
  styleUrls: ['./advanced-smil.component.scss']
})
export class AdvancedSmilComponent {

  public chart1 = chartData.chart1;

}
