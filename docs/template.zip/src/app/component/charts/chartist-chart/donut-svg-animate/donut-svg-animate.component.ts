import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-donut-svg-animate',
  templateUrl: './donut-svg-animate.component.html',
  styleUrls: ['./donut-svg-animate.component.scss']
})
export class DonutSvgAnimateComponent {

  public chart3 = chartData.chart3;

}
