import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-extreme-responsive-configuration',
  templateUrl: './extreme-responsive-configuration.component.html',
  styleUrls: ['./extreme-responsive-configuration.component.scss']
})
export class ExtremeResponsiveConfigurationComponent {

  public chart9 = chartData.chart9;

}
