import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-filled-holes-data',
  templateUrl: './filled-holes-data.component.html',
  styleUrls: ['./filled-holes-data.component.scss']
})
export class FilledHolesDataComponent {

  public chart12 = chartData.chart12;

}
