import { Component } from '@angular/core';
import * as chartData from '../../../../shared/data/component/charts/chartist';

@Component({
  selector: 'app-bi-polar-line-chart',
  templateUrl: './bi-polar-line-chart.component.html',
  styleUrls: ['./bi-polar-line-chart.component.scss']
})
export class BiPolarLineChartComponent {

  public chart4 = chartData.chart4;

}
