import { Component, EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-chats',
  templateUrl: './chats.component.html',
  styleUrls: ['./chats.component.scss']
})
export class ChatsComponent {

  @Output() filterValue = new EventEmitter<boolean>();

  public open: boolean = false;

  openFilter(){
    this.open =! this.open
    this.filterValue.emit(this.open)
  }


}
