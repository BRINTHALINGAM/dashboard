import { Component } from '@angular/core';
import { Value } from 'sass';

@Component({
  selector: 'app-chat-app',
  templateUrl: './chat-app.component.html',
  styleUrls: ['./chat-app.component.scss']
})
export class ChatAppComponent {

  public filterValue: boolean;
  receiverFilterValue(value:boolean){
    this.filterValue = value;
  }
}
