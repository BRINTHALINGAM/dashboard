import { Component } from '@angular/core';
import { chartUser } from '../../../../shared/data/component/chat/chat';

@Component({
  selector: 'app-user-chat',
  templateUrl: './user-chat.component.html',
  styleUrls: ['./user-chat.component.scss']
})
export class UserChatComponent {

  public searchUsers = chartUser;

}
