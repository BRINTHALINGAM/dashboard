import { Component } from '@angular/core';
import { menuChat } from '../../../../shared/data/component/chat/chat';
@Component({
  selector: 'app-chat-tab',
  templateUrl: './chat-tab.component.html',
  styleUrls: ['./chat-tab.component.scss']
})
export class ChatTabComponent {

  public chatuser = menuChat;

  public active = 1;

}
