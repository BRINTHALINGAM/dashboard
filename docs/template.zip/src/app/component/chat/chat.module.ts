import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { ChatRoutingModule } from './chat-routing.module';
import { ChatAppComponent } from './chat-app/chat-app.component';
import { VideoChatComponent } from './video-chat/video-chat.component';
import { UserChatComponent } from './chat-app/user-chat/user-chat.component';
import { ChatTabComponent } from './chat-app/chat-tab/chat-tab.component';
import { ProfileTabComponent } from './chat-app/chat-tab/profile-tab/profile-tab.component';
import { UserVideoChatComponent } from './video-chat/user-video-chat/user-video-chat.component';
import { ChatsComponent } from './chat-app/chats/chats.component';

@NgModule({
  declarations: [
    ChatAppComponent,
    VideoChatComponent,
    UserChatComponent,
    ChatTabComponent,
    ProfileTabComponent,
    UserVideoChatComponent,
    ChatsComponent
  ],
  imports: [
    CommonModule,
    ChatRoutingModule,
    NgbNavModule
  ]
})
export class ChatModule { }
