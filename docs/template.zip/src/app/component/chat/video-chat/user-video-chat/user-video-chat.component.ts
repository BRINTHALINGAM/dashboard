import { Component } from '@angular/core';

@Component({
  selector: 'app-user-video-chat',
  templateUrl: './user-video-chat.component.html',
  styleUrls: ['./user-video-chat.component.scss']
})
export class UserVideoChatComponent {

}
