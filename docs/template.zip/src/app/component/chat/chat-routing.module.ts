import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChatAppComponent } from './chat-app/chat-app.component';
import { VideoChatComponent } from './video-chat/video-chat.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'chat-app',
        component: ChatAppComponent,
        data: {
          title: "Chat App",
          breadcrumb: "Chat App",
        }
      },
      {
        path: 'video-chat',
        component: VideoChatComponent,
        data: {
          title: "VideoChat",
          breadcrumb: "VideoChat",
        }
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChatRoutingModule { }
