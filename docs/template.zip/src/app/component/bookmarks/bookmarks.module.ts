import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BookmarksRoutingModule } from './bookmarks-routing.module';
import { BookmarksComponent } from './bookmarks.component';
import { BookmarkDataComponent } from './bookmark-data/bookmark-data.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { AddTagComponent } from './modal/add-tag/add-tag.component';
import { EditBookmarkComponent } from './modal/edit-bookmark/edit-bookmark.component';
import { NewBookmarkComponent } from './modal/new-bookmark/new-bookmark.component';

@NgModule({
  declarations: [
    BookmarksComponent,
    BookmarkDataComponent,
    SideMenuComponent,
    AddTagComponent,
    EditBookmarkComponent,
    NewBookmarkComponent,
  ],
  imports: [
    CommonModule,
    BookmarksRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule

  ]
})
export class BookmarksModule { }
