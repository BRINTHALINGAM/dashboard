import { Component, OnInit, Output } from '@angular/core';
import { allBookmarkData } from '../../../shared/data/component/bookmark/bookmarks';
import { tagData } from '../../../shared/data/component/bookmark/bookmarks';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddTagComponent } from '../modal/add-tag/add-tag.component';
import { NewBookmarkComponent } from '../modal/new-bookmark/new-bookmark.component';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent {


  @Output()selectedheading_id: number;
  @Output()selectegTagId: number;

  public open: boolean = false;

  public BookmarkData = allBookmarkData;
  public tag = tagData;

  constructor(private modalService: NgbModal) { }

  openMenu() {
    this.open = !this.open
  }

  openAddBookmark() {
    const modalRef = this.modalService.open(NewBookmarkComponent, { size: 'lg' });
  }

  openAddTag() {
    const modalRef = this.modalService.open(AddTagComponent, { size: 'lg' });
  }

  getData(title_id: number) {
    const getHeadingData = this.BookmarkData.filter((data) => {
      return data.title_id === title_id
    })
    this.selectedheading_id = getHeadingData[0].title_id!
  }

  getTagData(title_id: number) {
    const getHeadingData = this.tag.filter((data) => {
      return data.title_id === title_id
    })
    this.selectegTagId = getHeadingData[0].title_id!
  }

}
