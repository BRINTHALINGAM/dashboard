import { Component } from '@angular/core';

@Component({
  selector: 'app-square-rating-bar',
  templateUrl: './square-rating-bar.component.html',
  styleUrls: ['./square-rating-bar.component.scss']
})
export class SquareRatingBarComponent {

  public squareRate = 1;

}
