import { Component } from '@angular/core';

@Component({
  selector: 'app-movie-rating-bar',
  templateUrl: './movie-rating-bar.component.html',
  styleUrls: ['./movie-rating-bar.component.scss']
})
export class MovieRatingBarComponent {

  public movieRate = 2;

}
