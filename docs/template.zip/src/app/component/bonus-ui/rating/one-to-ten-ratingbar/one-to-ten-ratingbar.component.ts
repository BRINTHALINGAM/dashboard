import { Component } from '@angular/core';

@Component({
  selector: 'app-one-to-ten-ratingbar',
  templateUrl: './one-to-ten-ratingbar.component.html',
  styleUrls: ['./one-to-ten-ratingbar.component.scss']
})
export class OneToTenRatingbarComponent {

  public faRate = 7;

}
