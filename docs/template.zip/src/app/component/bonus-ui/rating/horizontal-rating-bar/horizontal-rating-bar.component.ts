import { Component } from '@angular/core';

@Component({
  selector: 'app-horizontal-rating-bar',
  templateUrl: './horizontal-rating-bar.component.html',
  styleUrls: ['./horizontal-rating-bar.component.scss']
})
export class HorizontalRatingBarComponent {

  public verticalRate = 1;

}
