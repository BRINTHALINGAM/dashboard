import { Component } from '@angular/core';
import { autoPlayVariant, autovariantOption } from '../../../../shared/data/component/bonus-ui/owl-carousel/owl-carousel';

@Component({
  selector: 'app-auto-play-variant',
  templateUrl: './auto-play-variant.component.html',
  styleUrls: ['./auto-play-variant.component.scss']
})
export class AutoPlayVariantComponent {

  public autovariantoptionsData = autovariantOption;
  public autoVariantData = autoPlayVariant;

}
