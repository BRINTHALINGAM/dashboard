import { Component } from '@angular/core';
import { commonImg, urlNavigationsOptions } from '../../../../shared/data/component/bonus-ui/owl-carousel/owl-carousel';

@Component({
  selector: 'app-url-hash-navigations',
  templateUrl: './url-hash-navigations.component.html',
  styleUrls: ['./url-hash-navigations.component.scss']
})
export class UrlHashNavigationsComponent {

  public navigationsData = commonImg;
  public urlnavigationsoptionsData = urlNavigationsOptions

}
