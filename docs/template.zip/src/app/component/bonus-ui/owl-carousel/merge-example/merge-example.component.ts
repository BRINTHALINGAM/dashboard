import { Component } from '@angular/core';
import { commonImg, margeOption } from '../../../../shared/data/component/bonus-ui/owl-carousel/owl-carousel';

@Component({
  selector: 'app-merge-example',
  templateUrl: './merge-example.component.html',
  styleUrls: ['./merge-example.component.scss']
})
export class MergeExampleComponent {

  public margeData = commonImg;
  public margeOptionsData = margeOption;

}
