import { Component } from '@angular/core';
import { autoPlayVariant, MouseWheeloption } from '../../../../shared/data/component/bonus-ui/owl-carousel/owl-carousel';

@Component({
  selector: 'app-mouse-wheel-variant',
  templateUrl: './mouse-wheel-variant.component.html',
  styleUrls: ['./mouse-wheel-variant.component.scss']
})
export class MouseWheelVariantComponent {

  public autoVariantData = autoPlayVariant;
  public mousewheelData = MouseWheeloption;

}
