import { Component } from '@angular/core';
import { stagepaddingOptions, commonImg } from '../../../../shared/data/component/bonus-ui/owl-carousel/owl-carousel';

@Component({
  selector: 'app-stage-padding-example',
  templateUrl: './stage-padding-example.component.html',
  styleUrls: ['./stage-padding-example.component.scss']
})
export class StagePaddingExampleComponent {

  public stagepaddingData = commonImg;
  public stagepaddingOptionsData = stagepaddingOptions;

}
