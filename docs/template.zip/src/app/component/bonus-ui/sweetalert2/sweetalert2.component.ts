import { Component } from '@angular/core';

@Component({
  selector: 'app-sweetalert2',
  templateUrl: './sweetalert2.component.html',
  styleUrls: ['./sweetalert2.component.scss']
})
export class Sweetalert2Component {

}
