import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-pagination',
  templateUrl: './icon-pagination.component.html',
  styleUrls: ['./icon-pagination.component.scss']
})
export class IconPaginationComponent {

}
