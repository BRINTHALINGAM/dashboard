import { Component } from '@angular/core';

@Component({
  selector: 'app-alignment-pagination',
  templateUrl: './alignment-pagination.component.html',
  styleUrls: ['./alignment-pagination.component.scss']
})
export class AlignmentPaginationComponent {

}
