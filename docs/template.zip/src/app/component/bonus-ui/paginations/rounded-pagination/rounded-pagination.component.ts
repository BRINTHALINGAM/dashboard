import { Component } from '@angular/core';

@Component({
  selector: 'app-rounded-pagination',
  templateUrl: './rounded-pagination.component.html',
  styleUrls: ['./rounded-pagination.component.scss']
})
export class RoundedPaginationComponent {

}
