import { Component } from '@angular/core';

@Component({
  selector: 'app-default-pagination',
  templateUrl: './default-pagination.component.html',
  styleUrls: ['./default-pagination.component.scss']
})
export class DefaultPaginationComponent {

}
