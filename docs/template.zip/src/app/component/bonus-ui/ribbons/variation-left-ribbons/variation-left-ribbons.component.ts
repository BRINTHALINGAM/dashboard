import { Component } from '@angular/core';
import { LeftRibbons } from '../../../../shared/data/component/bonus-ui/ribbons/ribbons';

@Component({
  selector: 'app-variation-left-ribbons',
  templateUrl: './variation-left-ribbons.component.html',
  styleUrls: ['./variation-left-ribbons.component.scss']
})
export class VariationLeftRibbonsComponent {

  public leftRibbonsData = LeftRibbons;

}
