import { Component } from '@angular/core';
import { RightRibbons } from '../../../../shared/data/component/bonus-ui/ribbons/ribbons';

@Component({
  selector: 'app-variation-right-ribbons',
  templateUrl: './variation-right-ribbons.component.html',
  styleUrls: ['./variation-right-ribbons.component.scss']
})
export class VariationRightRibbonsComponent {

  public rightRibbonsData = RightRibbons;

}
