import { Component } from '@angular/core';

@Component({
  selector: 'app-border-secondary-state',
  templateUrl: './border-secondary-state.component.html',
  styleUrls: ['./border-secondary-state.component.scss']
})
export class BorderSecondaryStateComponent {

}
