import { Component } from '@angular/core';

@Component({
  selector: 'app-border-warning-state',
  templateUrl: './border-warning-state.component.html',
  styleUrls: ['./border-warning-state.component.scss']
})
export class BorderWarningStateComponent {

}
