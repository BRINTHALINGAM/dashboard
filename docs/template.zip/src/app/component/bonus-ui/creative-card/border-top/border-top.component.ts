import { Component } from '@angular/core';

@Component({
  selector: 'app-border-top',
  templateUrl: './border-top.component.html',
  styleUrls: ['./border-top.component.scss']
})
export class BorderTopComponent {

}
