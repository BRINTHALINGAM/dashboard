import { Component } from '@angular/core';

@Component({
  selector: 'app-border-bottom',
  templateUrl: './border-bottom.component.html',
  styleUrls: ['./border-bottom.component.scss']
})
export class BorderBottomComponent {

}
