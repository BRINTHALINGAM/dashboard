import { Component } from '@angular/core';

@Component({
  selector: 'app-border-primary-state',
  templateUrl: './border-primary-state.component.html',
  styleUrls: ['./border-primary-state.component.scss']
})
export class BorderPrimaryStateComponent {

}
