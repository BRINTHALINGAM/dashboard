import { Component } from '@angular/core';

@Component({
  selector: 'app-border-right',
  templateUrl: './border-right.component.html',
  styleUrls: ['./border-right.component.scss']
})
export class BorderRightComponent {

}
