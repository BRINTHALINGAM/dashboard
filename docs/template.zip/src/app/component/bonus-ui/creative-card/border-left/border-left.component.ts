import { Component } from '@angular/core';

@Component({
  selector: 'app-border-left',
  templateUrl: './border-left.component.html',
  styleUrls: ['./border-left.component.scss']
})
export class BorderLeftComponent {

}
