import { Component } from '@angular/core';

@Component({
  selector: 'app-absolute-card',
  templateUrl: './absolute-card.component.html',
  styleUrls: ['./absolute-card.component.scss']
})
export class AbsoluteCardComponent {

}
