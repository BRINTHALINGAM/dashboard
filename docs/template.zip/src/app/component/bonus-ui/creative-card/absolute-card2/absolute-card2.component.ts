import { Component } from '@angular/core';

@Component({
  selector: 'app-absolute-card2',
  templateUrl: './absolute-card2.component.html',
  styleUrls: ['./absolute-card2.component.scss']
})
export class AbsoluteCard2Component {

}
