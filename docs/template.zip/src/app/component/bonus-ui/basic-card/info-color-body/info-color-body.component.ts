import { Component } from '@angular/core';

@Component({
  selector: 'app-info-color-body',
  templateUrl: './info-color-body.component.html',
  styleUrls: ['./info-color-body.component.scss']
})
export class InfoColorBodyComponent {

}
