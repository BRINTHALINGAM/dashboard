import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-heading',
  templateUrl: './icon-heading.component.html',
  styleUrls: ['./icon-heading.component.scss']
})
export class IconHeadingComponent {

}
