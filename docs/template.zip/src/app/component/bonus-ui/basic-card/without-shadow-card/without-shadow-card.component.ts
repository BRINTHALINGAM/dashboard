import { Component } from '@angular/core';

@Component({
  selector: 'app-without-shadow-card',
  templateUrl: './without-shadow-card.component.html',
  styleUrls: ['./without-shadow-card.component.scss']
})
export class WithoutShadowCardComponent {

}
