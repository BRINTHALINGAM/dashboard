import { Component } from '@angular/core';

@Component({
  selector: 'app-info-color-header',
  templateUrl: './info-color-header.component.html',
  styleUrls: ['./info-color-header.component.scss']
})
export class InfoColorHeaderComponent {

}
