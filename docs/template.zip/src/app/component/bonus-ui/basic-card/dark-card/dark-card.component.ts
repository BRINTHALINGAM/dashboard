import { Component } from '@angular/core';

@Component({
  selector: 'app-dark-card',
  templateUrl: './dark-card.component.html',
  styleUrls: ['./dark-card.component.scss']
})
export class DarkCardComponent {

}
