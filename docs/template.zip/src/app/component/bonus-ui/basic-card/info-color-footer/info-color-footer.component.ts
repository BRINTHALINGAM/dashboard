import { Component } from '@angular/core';

@Component({
  selector: 'app-info-color-footer',
  templateUrl: './info-color-footer.component.html',
  styleUrls: ['./info-color-footer.component.scss']
})
export class InfoColorFooterComponent {

}
