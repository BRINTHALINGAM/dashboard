import { Component } from '@angular/core';

@Component({
  selector: 'app-default-breadcrumb',
  templateUrl: './default-breadcrumb.component.html',
  styleUrls: ['./default-breadcrumb.component.scss']
})
export class DefaultBreadcrumbComponent {

}
