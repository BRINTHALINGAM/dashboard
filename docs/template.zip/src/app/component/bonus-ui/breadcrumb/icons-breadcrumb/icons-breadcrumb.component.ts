import { Component } from '@angular/core';

@Component({
  selector: 'app-icons-breadcrumb',
  templateUrl: './icons-breadcrumb.component.html',
  styleUrls: ['./icons-breadcrumb.component.scss']
})
export class IconsBreadcrumbComponent {

}
