import { Component } from '@angular/core';

@Component({
  selector: 'app-divider-breadcrumb',
  templateUrl: './divider-breadcrumb.component.html',
  styleUrls: ['./divider-breadcrumb.component.scss']
})
export class DividerBreadcrumbComponent {

}
