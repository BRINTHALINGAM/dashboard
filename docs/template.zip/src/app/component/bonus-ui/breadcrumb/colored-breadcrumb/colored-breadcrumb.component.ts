import { Component } from '@angular/core';

@Component({
  selector: 'app-colored-breadcrumb',
  templateUrl: './colored-breadcrumb.component.html',
  styleUrls: ['./colored-breadcrumb.component.scss']
})
export class ColoredBreadcrumbComponent {

}
