import { Component } from '@angular/core';
import { basicTimeline } from '../../../../shared/data/component/bonus-ui/timeline/timeline';

@Component({
  selector: 'app-basic-timeline',
  templateUrl: './basic-timeline.component.html',
  styleUrls: ['./basic-timeline.component.scss']
})
export class BasicTimelineComponent {

  public basictimelineData = basicTimeline;

}
