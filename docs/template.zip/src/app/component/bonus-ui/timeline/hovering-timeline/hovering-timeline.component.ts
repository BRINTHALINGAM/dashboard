import { Component } from '@angular/core';

@Component({
  selector: 'app-hovering-timeline',
  templateUrl: './hovering-timeline.component.html',
  styleUrls: ['./hovering-timeline.component.scss']
})
export class HoveringTimelineComponent {

}
