import { Component } from '@angular/core';

@Component({
  selector: 'app-variation-timeline',
  templateUrl: './variation-timeline.component.html',
  styleUrls: ['./variation-timeline.component.scss']
})
export class VariationTimelineComponent {

}
