import { Component } from '@angular/core';

@Component({
  selector: 'app-meet-up',
  templateUrl: './meet-up.component.html',
  styleUrls: ['./meet-up.component.scss']
})
export class MeetUpComponent {

}
