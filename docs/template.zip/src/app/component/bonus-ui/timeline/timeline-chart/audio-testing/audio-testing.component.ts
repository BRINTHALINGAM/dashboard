import { Component } from '@angular/core';

@Component({
  selector: 'app-audio-testing',
  templateUrl: './audio-testing.component.html',
  styleUrls: ['./audio-testing.component.scss']
})
export class AudioTestingComponent {

}
