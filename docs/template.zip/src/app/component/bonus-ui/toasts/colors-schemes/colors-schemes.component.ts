import { Component } from '@angular/core';

@Component({
  selector: 'app-colors-schemes',
  templateUrl: './colors-schemes.component.html',
  styleUrls: ['./colors-schemes.component.scss']
})
export class ColorsSchemesComponent {

  public colorschemes: boolean = true;

  close() {
    this.colorschemes = false;
  }
}
