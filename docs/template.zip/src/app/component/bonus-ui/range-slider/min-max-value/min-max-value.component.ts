import { Component } from '@angular/core';
import { Options } from 'ngx-slider-v2';

@Component({
  selector: 'app-min-max-value',
  templateUrl: './min-max-value.component.html',
  styleUrls: ['./min-max-value.component.scss']
})
export class MinMaxValueComponent {

  value2: number = 550;
  maxvalue: number = 100;

  options: Options = {
    floor: 100,
    ceil: 1000
  };

}
