import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BarRatingModule } from "ngx-bar-rating";
import { SharedModule } from '../../shared/shared.module';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { BonusUiRoutingModule } from './bonus-ui-routing.module';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { NgxSliderModule } from 'ngx-slider-v2';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ImageCropperModule } from 'ngx-image-cropper';

import { ToastsComponent } from './toasts/toasts.component';
import { LiveToastComponent } from './toasts/live-toast/live-toast.component';
import { RatingComponent } from './rating/rating.component';
import { OneToTenRatingbarComponent } from './rating/one-to-ten-ratingbar/one-to-ten-ratingbar.component';
import { MovieRatingBarComponent } from './rating/movie-rating-bar/movie-rating-bar.component';
import { SquareRatingBarComponent } from './rating/square-rating-bar/square-rating-bar.component';
import { StarRatingBarComponent } from './rating/star-rating-bar/star-rating-bar.component';
import { HorizontalRatingBarComponent } from './rating/horizontal-rating-bar/horizontal-rating-bar.component';
import { CurrentRatingBarComponent } from './rating/current-rating-bar/current-rating-bar.component';
import { DropzoneComponent } from './dropzone/dropzone.component';
import { DefaultFileUploadComponent } from './dropzone/default-file-upload/default-file-upload.component';
import { ImagePerviewComponent } from './dropzone/image-perview/image-perview.component';
import { MultiFileUploadComponent } from './dropzone/multi-file-upload/multi-file-upload.component';
import { SingleFileUploadComponent } from './dropzone/single-file-upload/single-file-upload.component';
import { Sweetalert2Component } from './sweetalert2/sweetalert2.component';
import { BasicExampleComponent } from './sweetalert2/basic-example/basic-example.component';
import { TitleTextAlertComponent } from './sweetalert2/title-text-alert/title-text-alert.component';
import { InfoAlertComponent } from './sweetalert2/info-alert/info-alert.component';
import { WarningAlertComponent } from './sweetalert2/warning-alert/warning-alert.component';
import { PikachuAlertComponent } from './sweetalert2/pikachu-alert/pikachu-alert.component';
import { QuestionsAlertComponent } from './sweetalert2/questions-alert/questions-alert.component';
import { UsernameAlertComponent } from './sweetalert2/username-alert/username-alert.component';
import { SuccessMessageComponent } from './sweetalert2/success-message/success-message.component';
import { DangerAlertComponent } from './sweetalert2/danger-alert/danger-alert.component';
import { WarningModeComponent } from './sweetalert2/warning-mode/warning-mode.component';
import { AutoCloseTimerComponent } from './sweetalert2/auto-close-timer/auto-close-timer.component';
import { AjaxRequestMovieComponent } from './sweetalert2/ajax-request-movie/ajax-request-movie.component';
import { OwlCarouselComponent } from './owl-carousel/owl-carousel.component';
import { SlidesOnlyComponent } from './owl-carousel/slides-only/slides-only.component';
import { MouseWheelVariantComponent } from './owl-carousel/mouse-wheel-variant/mouse-wheel-variant.component';
import { AutoPlayVariantComponent } from './owl-carousel/auto-play-variant/auto-play-variant.component';
import { RibbonsComponent } from './ribbons/ribbons.component';
import { VariationLeftRibbonsComponent } from './ribbons/variation-left-ribbons/variation-left-ribbons.component';
import { VariationRightRibbonsComponent } from './ribbons/variation-right-ribbons/variation-right-ribbons.component';
import { PaginationsComponent } from './paginations/paginations.component';
import { DefaultPaginationComponent } from './paginations/default-pagination/default-pagination.component';
import { ActiveDisabledPaginationComponent } from './paginations/active-disabled-pagination/active-disabled-pagination.component';
import { IconPaginationComponent } from './paginations/icon-pagination/icon-pagination.component';
import { RoundedPaginationComponent } from './paginations/rounded-pagination/rounded-pagination.component';
import { AlignmentPaginationComponent } from './paginations/alignment-pagination/alignment-pagination.component';
import { PaginationSizingComponent } from './paginations/pagination-sizing/pagination-sizing.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { DefaultBreadcrumbComponent } from './breadcrumb/default-breadcrumb/default-breadcrumb.component';
import { DividerBreadcrumbComponent } from './breadcrumb/divider-breadcrumb/divider-breadcrumb.component';
import { IconsBreadcrumbComponent } from './breadcrumb/icons-breadcrumb/icons-breadcrumb.component';
import { VariationBreadcrumbComponent } from './breadcrumb/variation-breadcrumb/variation-breadcrumb.component';
import { ColoredBreadcrumbComponent } from './breadcrumb/colored-breadcrumb/colored-breadcrumb.component';
import { RangeSliderComponent } from './range-slider/range-slider.component';
import { MinMaxValueComponent } from './range-slider/min-max-value/min-max-value.component';
import { DefaultRangeSliderComponent } from './range-slider/default-range-slider/default-range-slider.component';
import { CustomValuesComponent } from './range-slider/custom-values/custom-values.component';
import { PrettifyNumbersComponent } from './range-slider/prettify-numbers/prettify-numbers.component';
import { DisabledComponent } from './range-slider/disabled/disabled.component';
import { CenterExampleComponent } from './owl-carousel/center-example/center-example.component';
import { CrossFadeComponent } from './owl-carousel/cross-fade/cross-fade.component';
import { ImageCropperComponent } from './image-cropper/image-cropper.component';
import { BasicCardComponent } from './basic-card/basic-card.component';
import { SimpleCardComponent } from './basic-card/simple-card/simple-card.component';
import { FlatCardComponent } from './basic-card/flat-card/flat-card.component';
import { WithoutShadowCardComponent } from './basic-card/without-shadow-card/without-shadow-card.component';
import { IconHeadingComponent } from './basic-card/icon-heading/icon-heading.component';
import { DarkCardComponent } from './basic-card/dark-card/dark-card.component';
import { InfoColorHeaderComponent } from './basic-card/info-color-header/info-color-header.component';
import { InfoColorBodyComponent } from './basic-card/info-color-body/info-color-body.component';
import { InfoColorFooterComponent } from './basic-card/info-color-footer/info-color-footer.component';
import { CreativeCardComponent } from './creative-card/creative-card.component';
import { BorderLeftComponent } from './creative-card/border-left/border-left.component';
import { BorderRightComponent } from './creative-card/border-right/border-right.component';
import { BorderTopComponent } from './creative-card/border-top/border-top.component';
import { BorderBottomComponent } from './creative-card/border-bottom/border-bottom.component';
import { BorderPrimaryStateComponent } from './creative-card/border-primary-state/border-primary-state.component';
import { BorderWarningStateComponent } from './creative-card/border-warning-state/border-warning-state.component';
import { BorderSecondaryStateComponent } from './creative-card/border-secondary-state/border-secondary-state.component';
import { AbsoluteCardComponent } from './creative-card/absolute-card/absolute-card.component';
import { AbsoluteCard2Component } from './creative-card/absolute-card2/absolute-card2.component';
import { TimelineComponent } from './timeline/timeline.component';
import { BasicTimelineComponent } from './timeline/basic-timeline/basic-timeline.component';
import { HoveringTimelineComponent } from './timeline/hovering-timeline/hovering-timeline.component';
import { VariationTimelineComponent } from './timeline/variation-timeline/variation-timeline.component';
import { HorizontalTimelineComponent } from './timeline/horizontal-timeline/horizontal-timeline.component';
import { TimelineChartComponent } from './timeline/timeline-chart/timeline-chart.component';
import { ResponsiveExampleComponent } from './owl-carousel/responsive-example/responsive-example.component';
import { MergeExampleComponent } from './owl-carousel/merge-example/merge-example.component';
import { AutoWidthExampleComponent } from './owl-carousel/auto-width-example/auto-width-example.component';
import { UrlHashNavigationsComponent } from './owl-carousel/url-hash-navigations/url-hash-navigations.component';
import { AutoHeightExampleComponent } from './owl-carousel/auto-height-example/auto-height-example.component';
import { LazyLoadExampleComponent } from './owl-carousel/lazy-load-example/lazy-load-example.component';
import { RightLeftExampleComponent } from './owl-carousel/right-left-example/right-left-example.component';
import { StagePaddingExampleComponent } from './owl-carousel/stage-padding-example/stage-padding-example.component';
import { ColorsSchemesComponent } from './toasts/colors-schemes/colors-schemes.component';
import { StackingToastsComponent } from './toasts/stacking-toasts/stacking-toasts.component';
import { TranslucentToastsComponent } from './toasts/translucent-toasts/translucent-toasts.component';
import { DefaultToastComponent } from './toasts/default-toast/default-toast.component';
import { UniqueToastComponent } from './toasts/unique-toast/unique-toast.component';
import { MeetUpComponent } from './timeline/timeline-chart/meet-up/meet-up.component';
import { AudioTestingComponent } from './timeline/timeline-chart/audio-testing/audio-testing.component';
import { ResolutionsComponent } from './timeline/timeline-chart/resolutions/resolutions.component';

@NgModule({
  declarations: [
    ToastsComponent,
    LiveToastComponent,
    RatingComponent,
    OneToTenRatingbarComponent,
    MovieRatingBarComponent,
    SquareRatingBarComponent,
    StarRatingBarComponent,
    HorizontalRatingBarComponent,
    CurrentRatingBarComponent,
    DropzoneComponent,
    SingleFileUploadComponent,
    MultiFileUploadComponent,
    DefaultFileUploadComponent,
    ImagePerviewComponent,
    Sweetalert2Component,
    BasicExampleComponent,
    TitleTextAlertComponent,
    InfoAlertComponent,
    WarningAlertComponent,
    PikachuAlertComponent,
    QuestionsAlertComponent,
    UsernameAlertComponent,
    SuccessMessageComponent,
    DangerAlertComponent,
    WarningModeComponent,
    AutoCloseTimerComponent,
    AjaxRequestMovieComponent,
    OwlCarouselComponent,
    SlidesOnlyComponent,
    MouseWheelVariantComponent,
    AutoPlayVariantComponent,
    RibbonsComponent,
    VariationLeftRibbonsComponent,
    VariationRightRibbonsComponent,
    PaginationsComponent,
    DefaultPaginationComponent,
    ActiveDisabledPaginationComponent,
    IconPaginationComponent,
    RoundedPaginationComponent,
    AlignmentPaginationComponent,
    PaginationSizingComponent,
    BreadcrumbComponent,
    DefaultBreadcrumbComponent,
    DividerBreadcrumbComponent,
    IconsBreadcrumbComponent,
    VariationBreadcrumbComponent,
    ColoredBreadcrumbComponent,
    RangeSliderComponent,
    MinMaxValueComponent,
    DefaultRangeSliderComponent,
    CustomValuesComponent,
    PrettifyNumbersComponent,
    DisabledComponent,
    CenterExampleComponent,
    CrossFadeComponent,
    ImageCropperComponent,
    BasicCardComponent,
    SimpleCardComponent,
    FlatCardComponent,
    WithoutShadowCardComponent,
    IconHeadingComponent,
    DarkCardComponent,
    InfoColorHeaderComponent,
    InfoColorBodyComponent,
    InfoColorFooterComponent,
    CreativeCardComponent,
    BorderLeftComponent,
    BorderRightComponent,
    BorderTopComponent,
    BorderBottomComponent,
    BorderPrimaryStateComponent,
    BorderWarningStateComponent,
    BorderSecondaryStateComponent,
    AbsoluteCardComponent,
    AbsoluteCard2Component,
    TimelineComponent,
    BasicTimelineComponent,
    HoveringTimelineComponent,
    VariationTimelineComponent,
    HorizontalTimelineComponent,
    TimelineChartComponent,
    ResponsiveExampleComponent,
    MergeExampleComponent,
    AutoWidthExampleComponent,
    UrlHashNavigationsComponent,
    AutoHeightExampleComponent,
    AutoWidthExampleComponent,
    LazyLoadExampleComponent,
    RightLeftExampleComponent,
    StagePaddingExampleComponent,
    ColorsSchemesComponent,
    StackingToastsComponent,
    TranslucentToastsComponent,
    DefaultToastComponent,
    UniqueToastComponent,
    MeetUpComponent,
    AudioTestingComponent,
    ResolutionsComponent
  ],
  imports: [
    CommonModule,
    BonusUiRoutingModule,
    BarRatingModule,
    NgxDropzoneModule,
    FontAwesomeModule,
    CarouselModule,
    NgxSliderModule,
    ImageCropperModule,
    SharedModule,
  ]
})
export class BonusUiModule { }
