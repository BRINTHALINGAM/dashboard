import { Component, QueryList, ViewChildren } from '@angular/core';
import { Observable } from 'rxjs';
import { DecimalPipe } from '@angular/common';
import { OdersdataDirective, SortEvent } from '../../../../shared/directives/odersdata.directive';
import { orderHistory } from '../../../../shared/data/component/e-commerce/orders';
import { OrderService } from '../../../../shared/services/ecommerce/order.service';
import { ORDERS } from '../../../../shared/interface/odershistory';

@Component({
  selector: 'app-datatable-order-history',
  templateUrl: './datatable-order-history.component.html',
  styleUrls: ['./datatable-order-history.component.scss'],
  providers: [OrderService, DecimalPipe],

})
export class DatatableOrderHistoryComponent {

  public products$: Observable<ORDERS[]>;
  public total$: Observable<number>;
  public  Data:ORDERS[];
  public orderHistoryData = orderHistory;

  @ViewChildren(OdersdataDirective) headers: QueryList<OdersdataDirective>;

  constructor(public service: OrderService) {
    this.products$ = service.support$;
    this.total$ = service.total$;
  }

  ngOnInit() {
    this.products$.subscribe((res) => {
      this.Data = res;
    });
  }
  
  onSort({ column, direction }: SortEvent) {
    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });
    this.service.sortColumn = column;
    this.service.sortDirection = direction;
  }

}
