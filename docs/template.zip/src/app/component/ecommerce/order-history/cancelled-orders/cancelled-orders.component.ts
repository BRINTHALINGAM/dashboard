import { Component } from '@angular/core';
import { CancelledOrders } from '../../../../shared/data/component/e-commerce/orders';
import { Order } from '../../../../shared/data/component/e-commerce/orders';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-cancelled-orders',
  templateUrl: './cancelled-orders.component.html',
  styleUrls: ['./cancelled-orders.component.scss']
})
export class CancelledOrdersComponent {

  public rateing = 5;
  constructor(public config: NgbRatingConfig) {
    config.max = 5; config.readonly = true;
  }

  public cancelled = CancelledOrders;

  close(item: Order) {
    this.cancelled.splice(this.cancelled.indexOf(item), 1);
  }

}
