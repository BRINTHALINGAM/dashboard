import { Component } from '@angular/core';
import { ShippedOrders } from '../../../../shared/data/component/e-commerce/orders';
import { Order } from '../../../../shared/data/component/e-commerce/orders';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-shipped-orders',
  templateUrl: './shipped-orders.component.html',
  styleUrls: ['./shipped-orders.component.scss']
})
export class ShippedOrdersComponent {

  public rateing = 5;
  constructor(public config: NgbRatingConfig) {
    config.max = 5; config.readonly = true;
  }

  public shipped = ShippedOrders;

  close(item: Order) {
    this.shipped.splice(this.shipped.indexOf(item), 1);
  }

}
