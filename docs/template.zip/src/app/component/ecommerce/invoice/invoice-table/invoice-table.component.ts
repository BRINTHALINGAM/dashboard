import { Component } from '@angular/core';
import { invoice } from '../../../../shared/data/component/e-commerce/invoice';

@Component({
  selector: 'app-invoice-table',
  templateUrl: './invoice-table.component.html',
  styleUrls: ['./invoice-table.component.scss']
})
export class InvoiceTableComponent {

  public invoiceData = invoice;

}
