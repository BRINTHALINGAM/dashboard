import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { BarRatingModule } from 'ngx-bar-rating';
import { NgxPrintModule } from 'ngx-print';
import { HttpClientModule } from '@angular/common/http';
import { GalleryModule } from '@ks89/angular-modal-gallery';
import { NgxSliderModule } from 'ngx-slider-v2';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { EcommerceRoutingModule } from './ecommerce-routing.module';

import { ProductComponent } from './product/product.component';
import { FilterComponent } from './product/filter/filter.component';
import { ProductBoxComponent } from './product/product-box/product-box.component';
import { QuickViewComponent } from './product/quick-view/quick-view.component';
import { OdersdataDirective } from '../../shared/directives/odersdata.directive';
import { ProductPageComponent } from './product-page/product-page.component';
import { ProductListComponent } from './product-list/product-list.component';
import { DetailsComponent } from './product-page/details/details.component';
import { BrandComponent } from './product-page/brand/brand.component';
import { DescriptionTabComponent } from './product-page/description-tab/description-tab.component';
import { ProductListDirective } from '../../shared/directives/product-list.directive';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { CreditCardComponent } from './payment-details/credit-card/credit-card.component';
import { DebitCardComponent } from './payment-details/debit-card/debit-card.component';
import { CodComponent } from './payment-details/cod/cod.component';
import { EmiComponent } from './payment-details/emi/emi.component';
import { NetBankingComponent } from './payment-details/net-banking/net-banking.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { NewOrdersComponent } from './order-history/new-orders/new-orders.component';
import { ShippedOrdersComponent } from './order-history/shipped-orders/shipped-orders.component';
import { CancelledOrdersComponent } from './order-history/cancelled-orders/cancelled-orders.component';
import { DatatableOrderHistoryComponent } from './order-history/datatable-order-history/datatable-order-history.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PricingComponent } from './pricing/pricing.component';
import { InvoiceTableComponent } from './invoice/invoice-table/invoice-table.component';
import { BillingDetailsComponent } from './checkout/billing-details/billing-details.component';
import { ProductTotalComponent } from './checkout/product-total/product-total.component';
import { SimpleCardPricingComponent } from './pricing/simple-card-pricing/simple-card-pricing.component';
import { BecomeMemberComponent } from './pricing/become-member/become-member.component';

@NgModule({
  declarations: [
    ProductComponent,
    FilterComponent,
    ProductBoxComponent,
    QuickViewComponent,
    ProductPageComponent,
    ProductListComponent,
    DetailsComponent,
    BrandComponent,
    DescriptionTabComponent,
    PaymentDetailsComponent,
    CreditCardComponent,
    DebitCardComponent,
    CodComponent,
    EmiComponent,
    NetBankingComponent,
    OrderHistoryComponent,
    NewOrdersComponent,
    ShippedOrdersComponent,
    CancelledOrdersComponent,
    DatatableOrderHistoryComponent,
    InvoiceComponent,
    CartComponent,
    WishlistComponent,
    CheckoutComponent,
    PricingComponent,
    InvoiceTableComponent,
    BillingDetailsComponent,
    ProductTotalComponent,
    SimpleCardPricingComponent,
    BecomeMemberComponent,
    ProductListDirective,
    OdersdataDirective
  ],
  imports: [
    CommonModule,
    EcommerceRoutingModule,
    HttpClientModule,
    BarRatingModule,
    NgxDropzoneModule,
    FormsModule,
    SharedModule,
    NgxSliderModule,
    CarouselModule,
    GalleryModule,
    NgxPrintModule
  ],
  exports: [
    ProductListComponent,
    ProductPageComponent
  ]

})
export class EcommerceModule { }
