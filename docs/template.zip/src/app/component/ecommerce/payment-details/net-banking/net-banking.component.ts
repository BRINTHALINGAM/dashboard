import { Component } from '@angular/core';

@Component({
  selector: 'app-net-banking',
  templateUrl: './net-banking.component.html',
  styleUrls: ['./net-banking.component.scss']
})
export class NetBankingComponent {

}
