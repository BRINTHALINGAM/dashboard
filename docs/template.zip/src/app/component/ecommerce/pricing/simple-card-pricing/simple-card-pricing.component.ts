import { Component } from '@angular/core';
import { simplePricingCard } from '../../../../shared/data/component/e-commerce/pricing';

@Component({
  selector: 'app-simple-card-pricing',
  templateUrl: './simple-card-pricing.component.html',
  styleUrls: ['./simple-card-pricing.component.scss']
})
export class SimpleCardPricingComponent {

  public simplepricing = simplePricingCard;

}
