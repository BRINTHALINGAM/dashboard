import { Component } from '@angular/core';

@Component({
  selector: 'app-product-total',
  templateUrl: './product-total.component.html',
  styleUrls: ['./product-total.component.scss']
})
export class ProductTotalComponent {

}
